const deployedAddress = '0x0D0f25895923f089f37F82B28D82B9CDc864b238'

export default deployedAddress
